package main;

public class Rectangle extends Shape{

	
	
	public Rectangle(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int area() {
		// TODO Auto-generated method stub
		return x*y;
	}

}
