package main;

public class Line {
	
	private int x;
	private int y;

	public Line(int x , int y)
	{
		this.x=x;
		this.y=y;
	}

}
